using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Web;

namespace Lab_1_Number_Guess.Pages
{
    public class PlayModel : PageModel
    {
        private int answer;

        public string Message { get; set; }

        public int Answer
        {
            get { return answer; }
            set { answer = value; }
        }

        NumberGuess ng;
        const string RND_NUM = "Random_Number";

        //on get request
        public void OnGet()
        {
            ng = new NumberGuess();
            answer = ng.Number;
            SaveNumber(answer);
            Message = "Enter your guess below:";
        }
        
        //on post request
        public IActionResult OnPost()
        {
            try
            {
                NumberGuess ng = new NumberGuess(GetNumber());
                int guess = int.Parse(Request.Form["guess"]);
                //if the checkanswer method finds a match then it will select a new random number, will return display text string
                //best practice would have been to return a value then assign the string based on value since the text of the message should be on presentation layer and not business
                Message = ng.CheckAnswer(guess);
                //updating session data in case the number changed
                SaveNumber(ng.Number);
            }
            catch
            {
                //if something above failed then have them try again
                Message = "Oops, we couldn't check that number, try again!";
            }
            return Page();
        }
        //assign number to session
        public void SaveNumber(int number)
        {
            HttpContext.Session.SetInt32(RND_NUM,number);
        }

        public int GetNumber()
        {
            return (int)HttpContext.Session.GetInt32(RND_NUM);
        }
    }


}