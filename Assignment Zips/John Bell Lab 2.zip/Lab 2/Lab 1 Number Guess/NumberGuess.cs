﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_1_Number_Guess
{
    public class NumberGuess
    {

        private int num;

        public int Number
        {
            get { return num; }
            set { num = value; }
        }

        public NumberGuess()
        {
            num = RandomNumber();
        }

        public NumberGuess(int number)
        {
            num = number;
        }

        public int RandomNumber()
        {
            Random rn = new Random();
            return rn.Next(1, 1000);
        }

        public string CheckAnswer(int guess)
        {
            string message;
                if (guess > num) message = "Too High!<br />&nbsp;<br />Guess again:";
                else if (guess < num) message = "Too Low!<br />&nbsp;<br />You'll get it this time!";
                else
                {
                    message = "Wow! You got it!<br /><font size=\"+1\">The Number Was " + num + "!</font><br />&nbsp;<br />I've got a harder one now..<br />Try and see if you can guess it!";
                    num = RandomNumber();
                }
            return message;
        }
    }
}
