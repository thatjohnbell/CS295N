using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace BookCatalog.Pages.Books
{
    public class SearchModel : PageModel
    {

        private readonly BookContext _context;
        public SelectList Authors;


        [Display(Name = "Book Author")]
        public string BookAuthor {get; set;}

        [Display(Name = "Book Title")]
        public string BookTitle { get; set; }

        [Display(Name = "Book Publisher")]
        public string BookPublisher { get; set; }

        public SearchModel(BookContext context)
        {
            _context = context;
        }

        public IList<Book> Book { get;set; }


        public async Task OnGetAsync(string bookAuthor, string bookTitle, string bookPublisher, DateTime minDate, DateTime maxDate)
        {

            IQueryable<string> authorQuery = from m in _context.Book
                                            orderby m.Author
                                            select m.Author;

            var books = from b in _context.Book
                        select b;

            if (!String.IsNullOrEmpty(bookTitle))
            {
                books = books.Where(s => s.Title.Contains(bookTitle));
            }

            if (!String.IsNullOrEmpty(bookAuthor))
            {
                books = books.Where(x => x.Author == bookAuthor);
            }


            if (!String.IsNullOrEmpty(bookPublisher))
            {
                books = books.Where(x => x.Publisher.Contains(bookPublisher));
            }

            /*
            if (!DateTime.I && !DateTime.IsNullOrEmpty(maxDate))
            {
                books = books.Where(x => x.ReleaseDate);
            }
            */

            Authors = new SelectList(await authorQuery.Distinct().ToListAsync());
            Book = await books.ToListAsync();
        }
    }
}
