using System;
using Xunit;

namespace RPSGameTest
{
    public class LogicTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
